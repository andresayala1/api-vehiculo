package api.vehiculo2;

import java.util.Scanner;
import Model.*;
import Services.Ruta;

/**
 *
 * @author darks
 */
public class ApiVehiculo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese los datos del carro:");
        System.out.print("Marca: ");
        String marcaCarro = scanner.nextLine();
        System.out.print("Modelo: ");
        String modeloCarro = scanner.nextLine();
        System.out.print("Placa: ");
        String placaCarro = scanner.nextLine();
        System.out.print("VelocidadMax: ");
        int velocidadMaxCarro = scanner.nextInt();
        System.out.print("Marca: ");
        String TipoTraccionCarro = scanner.nextLine();
        
        Carro carro = new Carro(marcaCarro,modeloCarro,placaCarro,velocidadMaxCarro,TipoTraccionCarro);
        
        System.out.println("\nIngrese los datos de la moto:");
        System.out.print("Marca: ");
        String marcaMoto = scanner.nextLine();
        System.out.print("Modelo: ");
        String modeloMoto = scanner.nextLine();
        System.out.print("Placa: ");
        String placaMoto = scanner.nextLine();
        System.out.print("Velocidad Máxima: ");
        int velocidadMaximaMoto = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Cilindraje: ");
        int cilindrajeMoto = scanner.nextInt();
        Moto moto = new Moto(marcaMoto, modeloMoto, placaMoto, velocidadMaximaMoto, cilindrajeMoto);

        realizarPruebaRuta(carro);
        realizarPruebaRuta(moto);

        scanner.close();
    }
    
    public static void realizarPruebaRuta(Ruta vehiculo) {
        vehiculo.acelerar();
        vehiculo.frenar();
        vehiculo.estacionar();
        vehiculo.direccion();
    }
}
    

