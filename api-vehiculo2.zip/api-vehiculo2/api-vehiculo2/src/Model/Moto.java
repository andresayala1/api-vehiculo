/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Services.Ruta;



/**
 *
 * @author darks
 */
class Moto extends Vehiculo implements Ruta{
    private String VelocidadMax;
    private String Cilindraje;

    public Moto(String marca, String modelo, String placa, int velocidadMaxima) {
        super(marca, modelo, placa, velocidadMaxima);
        String cilindraje = null;
        this.Cilindraje = cilindraje;
    }

    /**
     * @return the VelocidadMax
     */
    public String getVelocidadMax() {
        return VelocidadMax;
    }

    /**
     * @param VelocidadMax the VelocidadMax to set
     */
    public void setVelocidadMax(String VelocidadMax) {
        this.VelocidadMax = VelocidadMax;
    }

    /**
     * @return the Cilindraje
     */
    public String getCilindraje() {
        return Cilindraje;
    }

    /**
     * @param Cilindraje the Cilindraje to set
     */
    public void setCilindraje(String Cilindraje) {
        this.Cilindraje = Cilindraje;
    }

    @Override
    public void acelerar() {
        System.out.println("Acelerando la moto...");
    }

    @Override
    public void frenar() {
        System.out.println("Frenando la moto...");
    }

    @Override
    public void estacionar() {
      System.out.println("Estacionando la moto...");
    }

    @Override
    public void direccion() {
        System.out.println("Direccionando la moto...");
    }
    
    
}
