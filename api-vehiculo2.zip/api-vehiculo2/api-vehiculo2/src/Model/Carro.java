package Model;

import Services.Ruta;


/**
 *
 * @author darks
 */
class Carro extends Vehiculo implements Ruta {
    
    String TipoTraccion;


    public Carro(int VeloMax, String TipoTraccion, String marca, String modelo, String placa, int velocidadMax) {
        super(marca, modelo, placa, velocidadMax);
        this.TipoTraccion = TipoTraccion;
    }


    @Override
    public void acelerar() {
        System.out.println("Acelerando el carro..." + marca);
    }

    @Override
    public void frenar() {
        System.out.println("Frenando el carro..." + marca);
    }

    @Override
    public void estacionar() {
        System.out.println("Estacionando el carro..." + marca);
    }

    @Override
    public void direccion() {
        System.out.println("Direccionando el carro..." + marca);
    }
}
